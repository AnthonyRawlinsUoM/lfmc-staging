import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {jqxRangeSelectorComponent} from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxrangeselector';

@Component({
  selector: 'app-range-selector',
  templateUrl: './range-selector.component.html',
  styleUrls: ['./range-selector.component.css']
})
export class RangeSelectorComponent implements OnInit {
  @ViewChild('rangeSelector') myRangeSelector: jqxRangeSelectorComponent;


  @Input() min: Date = new Date(2017, 0, 1);
  @Input() max: Date = new Date(2018, 11, 31);
  @Input() range: any = { from: new Date(2017, 3, 15), to: new Date(2017, 3, 29) };

  @Output() rangeChange: EventEmitter<any> = new EventEmitter();


  constructor() { }

  ngOnInit() {
  }

  update() {
    this.rangeChange.emit(this.myRangeSelector.getRange());
  }
}
